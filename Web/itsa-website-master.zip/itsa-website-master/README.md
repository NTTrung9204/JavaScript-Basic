# ITSA Website

Information Technology Students Association is a student committee at Sardar Patel Institute of Technology. This website provides a track of our recent activities and an introduction to the students of our department.

## Installation

Prerequisites: [npm](http://npmjs.com)

1. `npm install -g bower` (should be executed once)

2. `bower install` (should be executed everytime there is an update)